// two numbers sum//


#include<iostream>
using namespace std;

int main()
{
    int a,b,c;
    cout<<"Enter two numbers:";
    cin>>a>>b;
    c=a+b;
    cout<<c;
    return 0;
}
